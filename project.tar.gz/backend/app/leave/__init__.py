"""
Khởi tạo package leave.
"""
